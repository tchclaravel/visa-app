<form method="post">
    <textarea id="myeditorinstance">Hello, World!</textarea>
 </form>