@extends('client.layout.app_master')


@section('title') شروط الإستخدام  @endsection


@section('content')


<div class="seo-page col-md-10">
    <h2 class="my-4">شروط الإستخدام</h2>

    {!! $page->page_content !!}
</div>
@endsection