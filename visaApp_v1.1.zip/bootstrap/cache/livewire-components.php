<?php return array (
  'admin.traveler-form' => 'App\\Http\\Livewire\\Admin\\TravelerForm',
  'client.banks-form' => 'App\\Http\\Livewire\\Client\\BanksForm',
  'client.payment-form' => 'App\\Http\\Livewire\\Client\\PaymentForm',
  'client.traveler-form' => 'App\\Http\\Livewire\\Client\\TravelerForm',
  'client.visa-request-form' => 'App\\Http\\Livewire\\Client\\VisaRequestForm',
);