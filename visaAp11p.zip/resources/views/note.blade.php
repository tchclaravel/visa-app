{{-- 
    
|--------------------------------------------------------------------------
| KEY-TAB APPLICATON -> MAIN SECTIONS
|--------------------------------------------------------------------------

[1] ADMIN SECTION
    - login   
    - logout
    - update

[2] MAIN LAYOUT
    - home
    - sidebar

[3] WORKER SECTION
    - create
    - show
    - update
    - delete
    - search

[4] OCCUPATIONS SECTION
    - create
    - show
    - update
    - delete

[5] JOBS SECTION 
    - start job from worker account
    - create job from jobs page
    - show
    - test assign job to person working now 
    - mark as completed job 
    - jobs pages
    - delete


    
    
--}}