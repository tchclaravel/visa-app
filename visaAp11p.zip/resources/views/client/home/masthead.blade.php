<!-- Masthead-->
<header class="masthead" id="start">
    <div class="container">
        <div class="masthead-heading"> 
            كل شئ أصبح سهلاً!
        </div>
        <div class="masthead-heading sub-head" style="color:#fff;">
            نص تجريبي نص تجريبي نص تجريبي نص تجريبي نص تجريبي نص تجريبي 
        </div>

        <a class="btn text-white btn-lg text-uppercase" href="{{route('client.step_one')}}" style="background: #ee3000">أبدأ الآن</a>
    </div>
</header>
