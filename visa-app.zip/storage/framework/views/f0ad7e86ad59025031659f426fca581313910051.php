<!DOCTYPE html>
<html lang="ar" dir="rtl">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo $__env->yieldContent('title'); ?></title>

        
        <?php echo $__env->make('app.layout.include.style_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </head>
    <body id="page-top" dir="rtl">
        <!-- Navigation-->
        <?php echo $__env->make('app.layout.include.home-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main Content -->
        <div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- Footer-->
        <?php echo $__env->make('app.layout.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->make('app.layout.include.script_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\visaApp\resources\views/app/layout/home_master.blade.php ENDPATH**/ ?>