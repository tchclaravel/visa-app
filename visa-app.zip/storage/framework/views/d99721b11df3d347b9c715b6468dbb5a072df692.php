<!-- Favicon-->
<link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
<!-- Fontawesome cdn -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">        
<!-- Core theme CSS (includes Bootstrap)-->
<link href="<?php echo e(asset('app/template/css/styles.css')); ?>" rel="stylesheet" />

<!-- Bootstrap icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">


<!-- Arabic Droid Font -->
<link rel="stylesheet" media="screen" href="https://fontlibrary.org//face/droid-arabic-kufi" type="text/css"/>


<link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">

<!-- Custom Css -->
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/media.css')); ?>">
<?php /**PATH C:\xampp\htdocs\visaApp\resources\views/app/layout/include/style_links.blade.php ENDPATH**/ ?>