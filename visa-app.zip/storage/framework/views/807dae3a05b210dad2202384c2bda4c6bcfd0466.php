


<?php $__env->startSection('title'); ?> تأكيد الطلب <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row confirm-request">

    <div class="d-flex justify-content-center v-cenetr">
        <div class="row mt-5 mb-5 success">
                <img class="img-fluid d-block mx-auto" src="<?php echo e(asset('app/template/design/check.png')); ?>" alt="">
                <span class="nice">مبروك!</span> <br>
                <span class="mb-1">تم تأكيد الطلب</span>
                <hr>
                <span class="mt-1">رقم الطلب</span>
                <h1 class="mb-4">879454</h1>
                
                <span>
                    يمكنك متابعة هذا الطلب <br>
                    من حسابك الشخصي <a href="<?php echo e(route('profile')); ?>">من هنا</a>
                </span> 
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.layout.app_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visaApp\resources\views/app/confirmed_request.blade.php ENDPATH**/ ?>