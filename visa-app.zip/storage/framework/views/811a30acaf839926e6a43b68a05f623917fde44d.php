


<?php $__env->startSection('title'); ?> تسجيل الدخول  <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row login">

    <div class="d-flex justify-content-center v-cenetr">
        
        <form class="row g-4 mb-5 mt-5 request-form">
            <h4 class="text-center"> تسجيل الدخول</h5>

            <div class="col-12">
                <label for="email" class="form-label">البريد الإلكتروني</label>
                <input type="email" class="form-control" id="email" placeholder="البريد الإلكتروني هنا">
            </div>
    
            <div class="col-12">
                <label for="password" class="form-label"> كلمة السر</label>
                <input type="text" class="form-control" id="password" placeholder=" أكتب كلمة السر هنا">
            </div>

            <div class="col-12">
                <label for="phone" class="form-label">رقم الجوال</label>
                <input type="text" class="form-control" id="phone" placeholder="أكتب رقم الجوال إذا لم يكن لديك كلمة سر">
              </div>

            <div class="col-12 mb-2">
              <button type="submit" class="btn btn-primary">تسجيل دخول</button>
            </div>

        </form>
    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.layout.app_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visaApp\resources\views/app/user/login.blade.php ENDPATH**/ ?>