<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNavApp">
    <div class="container">
        <span class="nav_logo">تأشيرتك علينا</span>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            
            <i style="font-size: 30px; margin: 0 auto;" class="fas fa-bars ms-1"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                <li class="nav-item"><a class="nav-link" href="#">تسجيل دخول</a></li>
                <li class="nav-item"><a class="nav-link" href="#contact">إتصل بنا</a></li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\visaApp\resources\views/app/layout/include/header.blade.php ENDPATH**/ ?>